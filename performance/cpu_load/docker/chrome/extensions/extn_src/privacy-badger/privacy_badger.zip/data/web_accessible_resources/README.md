While the scripts here are exposed to websites (as per the web_accessible_resources manifest key), access is controlled by Privacy Badger via per-request single-use secret tokens.

Search for `warAccessTokens` for the exact implementation.
